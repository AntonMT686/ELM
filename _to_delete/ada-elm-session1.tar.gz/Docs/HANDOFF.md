# ADA-ELM — Session Handoff

> Read this first when resuming. Then `Docs/PROJECT_CONTEXT.md` and `Docs/ARCHITECTURE_WORKFLOWS.md` (both have an
> **"ADA-ELM implementation notes"** section at the end). Keep this file updated at the end of every session.

**Last updated:** 2026-11-03 (session 1)
**Repository root:** `D:\Projects\products\ADA-ELM`
**Legacy reference (data migration only):** `D:\Projects\products\PMS`. Not inspected yet; this session didn't have access to that folder.

---

## 1. Decisions taken

| Topic | Decision |
|---|---|
| Product | ADA-ELM: engineering-first (Aircraft → System → Subsystem → LRU → SRU/ECFM) plus non-engineering/administrative flows on the same document and workflow engine. The legacy PMS design is **not** reused. |
| Frontend UI | **Mantine 7.15** (user switched from AntD mid-session 1), Tabler icons, Mantine Charts (Recharts), Spotlight (Ctrl+K), React Flow, PDF.js. Inter font bundled via `@fontsource-variable`. No CDN. |
| Backend | FastAPI modular monolith, SQLAlchemy 2 (sync), UUID PKs, `version` optimistic-locking columns, portable types (SQL Server-friendly). |
| DB | PostgreSQL 16 (prod), SQLite (dev/tests). Alembic baseline `0001_baseline` uses `metadata.create_all`. **From the next schema change onward, use `alembic revision --autogenerate`.** |
| Auth | Local accounts with Argon2id. HttpOnly `elm_session` JWT cookie, SameSite=strict. CSRF double-submit (`elm_csrf` cookie + `X-CSRF-Token` header). Lockout after 5 failures. LDAP/AD adapter still to be done (`auth_source='ldap'` returns `LDAP_NOT_CONFIGURED`). |
| Authorization | Permission catalogue (`app/core/permissions.py`) → configurable roles → **scoped** assignments (GLOBAL / ORG_UNIT / PROJECT / ENG_ITEM, with descendants). Document visibility is filtered in SQL (`services/authz.py::document_visibility_clause`). The sysadmin flag gives **no** approve/release rights. |
| Workflow | Versioned JSON spec (`services/workflow_spec.py`), validated before publish. Instances stay pinned to their version. Stage types: prepare / review / approval / signature / acknowledge. Modes: all / any / quorum. Assignee: initiator / pick (with role eligibility) / role (auto) / named users. Supports SoD exclusions, checklists, SLA, skip conditions, weights, and auto-release on completion. Bindings resolve to the most specific match; ambiguous matches raise an error. |
| Review binding | Reviews bind to revision **iteration + SHA-256**. The revision is locked while in review. "Request changes" ends the cycle, the author edits (new iteration), then resubmits (cycle N+1). |
| Revisions | Letters A, B, C… (I and O skipped) or numeric. Every save is kept as an iteration (`revision_iterations`). Nothing is overwritten. A new revision is allowed only after release or withdrawal. |
| Signatures | Adapter contract in `services/signature.py`. `dev_local_ca` makes **real RSA-PSS/SHA-256** signatures with a local dev CA (keys kept in `ELM_PKI_DIR`, never in the DB). The user re-enters their password to sign, and signing can't be delegated. **Production PKI/HSM is TBD by ADA.** |
| Release | Gate checks: current, approved, file integrity, hash bound, signatures valid. The author or owner can't release (SoD). The register entry is immutable; the previous release is superseded. Withdrawal needs a reason. Packages get a SHA-256-sealed manifest. |
| Audit | Append-only, hash-chained `audit_events` with a chain head row lock. `/audit/verify` checks the chain, and reading the audit trail is itself audited. |
| OnlyOffice | User's existing Document Server (JWT on). Backend signs the editor config. OnlyOffice fetches the file through a short-lived token URL. The save callback is JWT-verified, the download host is allow-listed (SSRF), and each save becomes a new iteration. Saves to locked revisions are rejected. |
| Worker | DB-backed loop (`python -m app.worker`) for SLA overdue reminders. No Redis yet. |

## 2. What's built (code exists; **not yet compiled or run**, see §3)

### Backend `backend/app`
- `core/`: config (env `ELM_*`), db, security, permissions, errors (no stack traces leak), deps (`Ctx` with audit helper).
- `models/`: org (OrgUnit, User, UserOrgAssignment, Role, RolePermission, RoleAssignment, Delegation), project (ProcessDomain, Project, ProjectOrgAssignment, ProjectMember, HierarchyLevel, EngineeringItem, EngineeringItemOrg, WorkItem), document (FileObject, DocumentType, NumberSequence, Document, DocumentRevision, RevisionIteration, DocumentRelation, DocumentAccessGrant, DocumentComment, DocumentAccessLog), workflow (Definition, Version, Binding, Instance, StageRun, Task, SignatureRecord, ReleasePackage(+Item), ReleaseRegisterEntry), system (AuditEvent, AuditChainHead, Notification, SystemSetting).
- `services/`: authz, audit, notify, storage (magic-byte checks), numbering, documents (templates stamped with number/title/approval table), workflow_spec, workflow_engine, signature, release, onlyoffice, progress (explainable roll-up), serial.
- `api/v1/`: auth, admin (org / users / roles / assignments / delegations / doc types / domains), engineering (projects, tree with roll-up, items), documents (register, detail, workflow view, history, content upload, revise, download/inline, relations, shares, comments, workflow plan, submit, withdraw, release checks, release, signature verify), workflow (inbox, decide, sign, reassign, designer CRUD/draft/publish/bindings), releases (register, withdraw, packages), dashboard, misc (notifications, search, audit, work items), onlyoffice (config/file/callback).
- `seed.py`: fictional ADA org (PD Head Directorate, FCS, AWS, STR, ICT, QA, ADMIN plus departments), 16 users, 13 roles, AMCA (5 levels, about 20 items) and MK1 (Aircraft→LRU→ECFM), 12 document types (engineering / management / non-engineering), 3 workflows. Demo documents are **driven through the real engine** (one released with 4 signatures, others in review, changes requested, approved, programme document in quorum concurrence, and admin documents auto-released).
- `tests/test_platform.py`: login/CSRF, scope isolation, the full lifecycle (SoD, checklist, request changes → resubmit, signing, wrong password, author can't release, release, revise → B), audit chain, dashboard/tree, and the OnlyOffice callback guard.

### Frontend `frontend/src` (Mantine)
App shell (collapsible dark nav, Ctrl+K Spotlight, theme toggle, notifications drawer). Pages:
Login · Home dashboard (KPIs, next actions, pipeline, aging, programme rings, directorate bars, throughput, activity) ·
**Action inbox** (grouped overdue/soon, j/k keys, live preview + lifecycle tracker, checklist-gated approve, request changes/reject, sign modal with password, reassign, delegations) ·
**Product structure explorer** (tree with level tags + progress bars, item panel with stacked status bar, docs/sub-items/tasks, add sub-item with automatic level) ·
Document register (filters, quick chips) and a **guided New Document wizard** (type → item, filtered by applicable level → template/upload) ·
**Document workspace** (header actions by permission, lifecycle tracker, smart Submit modal with eligible candidates per stage, release gate checklist, upload, revise, share, link, child doc; tabs: preview (OnlyOffice view/PDF.js/image), review history, revisions + iterations, signatures with verify, relation graph, discussion, access, audit) ·
Full-screen OnlyOffice editor · Release register + packages · Kanban tasks board (drag and drop) ·
**Visual workflow designer** (React Flow canvas, stage inspector, bindings, versions, validate & publish) ·
Audit trail with chain verify · Admin: organization tree, users and scoped roles, role × permission matrix, document types, projects and breakdown levels.

### Deploy
`docker-compose.yml` (db / backend / worker / web, optional `onlyoffice` profile), `backend/Dockerfile` (uses `backend/wheels` offline if present), `frontend/Dockerfile` + `nginx.conf` (CSP allows the OnlyOffice origin), `.env.example`, `deploy/scripts/build_offline_bundle.sh`, `install_offline.sh`.

## 3. Not verified yet. **Do this first next session.**
Session 1 had **no access to npm or PyPI** (egress blocked in both the cloud and the local shell), so nothing has been installed, compiled or run. Only `python -m compileall` passed.
1. `cd backend && pip install -r requirements-dev.txt && pytest -q`. Fix any failures (likely spots: FastAPI body-parameter inference, SQLite datetime tz handling, seed engine calls).
2. `cd frontend && npm install && npm run build`. Fix TypeScript errors (Mantine 7.15 prop names, `@mantine/charts` props, React Flow v12 types). Commit `package-lock.json`, since the offline build needs it.
3. `docker compose up -d --build`, sign in as each persona, and walk through: create → edit in OnlyOffice → submit → check → review → approve → 4 signatures → release by `cm.sharma`.
4. Check OnlyOffice networking: browser → `ELM_ONLYOFFICE_PUBLIC_URL`, OnlyOffice → `ELM_BACKEND_INTERNAL_URL` (web:80 proxies `/api`), backend → `ELM_ONLYOFFICE_INTERNAL_URL`. The JWT secret must match the Document Server.

## 4. Backlog (priority order)
1. Build/test fixes from §3, plus screenshots for UX review.
2. **Data migration from PMS** (`D:\Projects\products\PMS`): request folder access, inspect its schema (ProFlow Yii2/MySQL per context), write `scripts/import_legacy/` with mapping, dry run, counts, SHA-256 reconciliation, and an exception report. `documents.legacy_ref` already exists.
3. LDAP/AD authentication adapter, MFA hook, session revocation table.
4. PDF report generation (reportlab is in requirements): release transmittal, document register, RTM, approval aging.
5. Engineering modules: requirements and traceability (DOORS/ReqIF import), change requests / ECR→ECN workflow on `WorkItem.kind=CHANGE_REQUEST`, baselines, verification and test evidence, SDLC modules for software work packages.
6. Self-hosted draw.io integration for design artefacts (`.drawio` is already an allowed type for DDD).
7. Watermarking / print and download controls by classification. Malware-scan adapter (`FileObject.scan_status`).
8. SLA working calendar and holidays, escalation to managers, email adapter.
9. Proper Alembic autogenerated migrations, a SQL Server compatibility test, backup/restore scripts, SBOM.
10. Production PKI/HSM signature adapter (PAdES if ADA picks PDF signing).

## 5. Open ADA decisions (still TBD)
PGD/TD meaning and permission mapping · official org list · classification labels and handling rules · numbering
schemes per document type · PKI/token standard · identity provider (LDAP/AD details) · retention · target OS/CPU · RPO/RTO.

## 6. Conventions
- API prefix `/api/v1`. Errors are `{error:{code,message,details,request_id}}`. Every mutating endpoint writes an audit event in the same transaction.
- Never hard-code directorates, roles, levels, stages or document types. Seed data is demo only.
- Frontend: `useAction()` for mutations (notifications + invalidation). Permissions come from `/auth/me`, and the UI hides actions but the server enforces them.
