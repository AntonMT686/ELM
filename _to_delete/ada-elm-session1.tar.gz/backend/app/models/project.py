"""Programme/project, configurable product breakdown (Aircraft → System → Subsystem → LRU → ...), work items."""
from __future__ import annotations

import uuid
from datetime import date, datetime

from sqlalchemy import Boolean, Date, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base
from app.models.base import IdMixin, TimestampMixin, VersionMixin


class ProcessDomain(IdMixin, TimestampMixin, Base):
    """SOFTWARE | HARDWARE | SYSTEMS | HYBRID | ADMIN | QUALITY ... configurable."""

    __tablename__ = "process_domains"
    code: Mapped[str] = mapped_column(String(40), unique=True)
    name: Mapped[str] = mapped_column(String(120))
    is_engineering: Mapped[bool] = mapped_column(Boolean, default=True)
    color: Mapped[str | None] = mapped_column(String(20))
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class Project(IdMixin, TimestampMixin, VersionMixin, Base):
    __tablename__ = "projects"
    code: Mapped[str] = mapped_column(String(40), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    programme: Mapped[str | None] = mapped_column(String(120))
    description: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(30), default="ACTIVE")  # PLANNED|ACTIVE|ON_HOLD|CLOSED
    lead_org_unit_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("org_units.id"))
    start_date: Mapped[date | None] = mapped_column(Date)
    end_date: Mapped[date | None] = mapped_column(Date)
    color: Mapped[str | None] = mapped_column(String(20))
    classification: Mapped[str | None] = mapped_column(String(40))

    levels: Mapped[list["HierarchyLevel"]] = relationship(order_by="HierarchyLevel.level_no", cascade="all, delete-orphan")


class ProjectOrgAssignment(IdMixin, TimestampMixin, Base):
    __tablename__ = "project_org_assignments"
    __table_args__ = (UniqueConstraint("project_id", "org_unit_id", name="uq_project_org"),)
    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id"), index=True)
    org_unit_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("org_units.id"), index=True)
    participation: Mapped[str] = mapped_column(String(20), default="CONTRIBUTOR")  # LEAD | CONTRIBUTOR | OVERSIGHT


class ProjectMember(IdMixin, TimestampMixin, Base):
    __tablename__ = "project_members"
    __table_args__ = (UniqueConstraint("project_id", "user_id", name="uq_project_member"),)
    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id"), index=True)
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id"), index=True)


class HierarchyLevel(IdMixin, Base):
    """Configurable breakdown levels per project. e.g. 1 AIRCRAFT, 2 SYSTEM, 3 SUBSYSTEM, 4 LRU, 5 SRU/ECFM."""

    __tablename__ = "hierarchy_levels"
    __table_args__ = (UniqueConstraint("project_id", "level_no", name="uq_level_no"),)
    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id"), index=True)
    level_no: Mapped[int] = mapped_column(Integer)
    code: Mapped[str] = mapped_column(String(30))
    name: Mapped[str] = mapped_column(String(80))
    icon: Mapped[str | None] = mapped_column(String(40))
    color: Mapped[str | None] = mapped_column(String(20))


class EngineeringItem(IdMixin, TimestampMixin, VersionMixin, Base):
    __tablename__ = "engineering_items"
    __table_args__ = (UniqueConstraint("project_id", "code", name="uq_item_code"),)
    project_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("projects.id"), index=True)
    parent_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("engineering_items.id"), index=True)
    level_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("hierarchy_levels.id"))
    code: Mapped[str] = mapped_column(String(60))
    name: Mapped[str] = mapped_column(String(200))
    part_number: Mapped[str | None] = mapped_column(String(80))
    description: Mapped[str | None] = mapped_column(Text)
    domain_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("process_domains.id"))
    lead_org_unit_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("org_units.id"))
    technical_owner_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id"))
    lifecycle_phase: Mapped[str] = mapped_column(String(40), default="CONCEPT")  # configurable phase label
    status: Mapped[str] = mapped_column(String(30), default="ACTIVE")
    path: Mapped[str] = mapped_column(String(2000), index=True, default="/")
    sort_order: Mapped[int] = mapped_column(default=0)

    level: Mapped[HierarchyLevel] = relationship()


class EngineeringItemOrg(IdMixin, Base):
    __tablename__ = "engineering_item_orgs"
    __table_args__ = (UniqueConstraint("item_id", "org_unit_id", name="uq_item_org"),)
    item_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("engineering_items.id"), index=True)
    org_unit_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("org_units.id"), index=True)
    role: Mapped[str] = mapped_column(String(20), default="CONTRIBUTOR")  # LEAD | CONTRIBUTOR | REVIEWER


class WorkItem(IdMixin, TimestampMixin, VersionMixin, Base):
    """Task / action item — engineering or non-engineering (admin, procurement, quality, meetings ...)."""

    __tablename__ = "work_items"
    key: Mapped[str] = mapped_column(String(40), unique=True)
    title: Mapped[str] = mapped_column(String(300))
    description: Mapped[str | None] = mapped_column(Text)
    kind: Mapped[str] = mapped_column(String(30), default="TASK")  # TASK | ACTION | MILESTONE | CHANGE_REQUEST | ISSUE
    status: Mapped[str] = mapped_column(String(30), default="TODO")  # TODO | IN_PROGRESS | BLOCKED | DONE | CANCELLED
    priority: Mapped[str] = mapped_column(String(10), default="MEDIUM")
    project_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("projects.id"), index=True)
    item_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("engineering_items.id"), index=True)
    org_unit_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("org_units.id"), index=True)
    document_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("documents.id"), index=True)
    domain_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("process_domains.id"))
    assignee_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id"), index=True)
    reporter_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id"))
    start_date: Mapped[date | None] = mapped_column(Date)
    due_date: Mapped[date | None] = mapped_column(Date, index=True)
    progress: Mapped[float] = mapped_column(Float, default=0.0)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
