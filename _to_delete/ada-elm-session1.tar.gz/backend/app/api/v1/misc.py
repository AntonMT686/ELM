"""Notifications, global search (command palette), audit trail, work items (engineering & non-engineering tasks)."""
from __future__ import annotations

import uuid
from datetime import date

from fastapi import APIRouter, Body, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy import func, or_, select, update

from app.core.db import utcnow
from app.core.deps import Ctx, get_ctx, get_or_404
from app.core.errors import Forbidden
from app.models import AuditEvent, Document, EngineeringItem, Notification, Project, User, WorkItem
from app.services import audit as auditsvc
from app.services.authz import document_visibility_clause
from app.services.notify import notify
from app.services.numbering import next_seq
from app.services.serial import iso, user_brief

router = APIRouter(tags=["platform"])


# ------------------------------------------------------------------ notifications
@router.get("/notifications")
def notifications(unread_only: bool = False, limit: int = Query(50, le=200), ctx: Ctx = Depends(get_ctx)):
    q = select(Notification).where(Notification.user_id == ctx.user.id)
    if unread_only:
        q = q.where(Notification.read_at.is_(None))
    rows = ctx.db.execute(q.order_by(Notification.created_at.desc()).limit(limit)).scalars().all()
    unread = ctx.db.execute(select(func.count(Notification.id)).where(Notification.user_id == ctx.user.id, Notification.read_at.is_(None))).scalar()
    return {"unread": unread, "items": [{"id": str(n.id), "kind": n.kind, "title": n.title, "body": n.body, "link": n.link, "severity": n.severity, "created_at": iso(n.created_at), "read": n.read_at is not None} for n in rows]}


@router.post("/notifications/read")
def mark_read(ids: list[uuid.UUID] | None = Body(default=None), ctx: Ctx = Depends(get_ctx)):
    q = update(Notification).where(Notification.user_id == ctx.user.id, Notification.read_at.is_(None))
    if ids:
        q = q.where(Notification.id.in_(ids))
    ctx.db.execute(q.values(read_at=utcnow()))
    ctx.db.commit()
    return {"ok": True}


# ------------------------------------------------------------------ search
@router.get("/search")
def search(q: str = Query(min_length=1, max_length=100), ctx: Ctx = Depends(get_ctx)):
    like = f"%{q.lower()}%"
    vis = document_visibility_clause(ctx.db, ctx.p)
    dq = select(Document).where(or_(func.lower(Document.number).like(like), func.lower(Document.title).like(like)))
    if vis is not None:
        dq = dq.where(vis)
    docs = ctx.db.execute(dq.order_by(Document.updated_at.desc()).limit(8)).scalars().all()
    items = ctx.db.execute(select(EngineeringItem).where(or_(func.lower(EngineeringItem.code).like(like), func.lower(EngineeringItem.name).like(like), func.lower(func.coalesce(EngineeringItem.part_number, "")).like(like))).limit(8)).scalars().all()
    people = ctx.db.execute(select(User).where(User.is_active.is_(True), or_(func.lower(User.full_name).like(like), func.lower(User.username).like(like))).limit(5)).scalars().all()
    projects = {p.id: p for p in ctx.db.execute(select(Project)).scalars()}
    return {
        "documents": [{"id": str(d.id), "number": d.number, "title": d.title, "status": d.status} for d in docs],
        "items": [{"id": str(i.id), "code": i.code, "name": i.name, "level": i.level.name, "project_id": str(i.project_id), "project": projects[i.project_id].code} for i in items],
        "people": [user_brief(u) for u in people],
    }


# ------------------------------------------------------------------ audit
@router.get("/audit")
def audit_list(q: str | None = None, action: str | None = None, entity_type: str | None = None, actor_id: uuid.UUID | None = None, page: int = 1, page_size: int = Query(50, le=200), ctx: Ctx = Depends(get_ctx)):
    ctx.p.require("audit.view")
    stmt = select(AuditEvent)
    if q:
        stmt = stmt.where(func.lower(AuditEvent.summary).like(f"%{q.lower()}%"))
    if action:
        stmt = stmt.where(AuditEvent.action.like(f"{action}%"))
    if entity_type:
        stmt = stmt.where(AuditEvent.entity_type == entity_type)
    if actor_id:
        stmt = stmt.where(AuditEvent.actor_id == actor_id)
    total = ctx.db.execute(select(func.count()).select_from(stmt.subquery())).scalar()
    rows = ctx.db.execute(stmt.order_by(AuditEvent.seq.desc()).offset((page - 1) * page_size).limit(page_size)).scalars().all()
    ctx.audit("audit.read", "audit", None, "Audit trail viewed", {"q": q, "action": action})
    ctx.db.commit()
    return {"total": total, "items": [{"seq": e.seq, "at": iso(e.at), "action": e.action, "entity_type": e.entity_type, "entity_id": e.entity_id, "summary": e.summary, "outcome": e.outcome, "ip": e.ip,
                                       "actor": user_brief(ctx.db.get(User, e.actor_id)) if e.actor_id else None, "on_behalf_of": user_brief(ctx.db.get(User, e.on_behalf_of_id)) if e.on_behalf_of_id else None, "hash": e.hash, "prev_hash": e.prev_hash, "data": e.data} for e in rows]}


@router.get("/audit/verify")
def audit_verify(ctx: Ctx = Depends(get_ctx)):
    ctx.p.require("audit.view")
    return auditsvc.verify_chain(ctx.db)


# ------------------------------------------------------------------ work items
class WorkItemIn(BaseModel):
    title: str = Field(min_length=3, max_length=300)
    description: str | None = None
    kind: str = Field(default="TASK", pattern=r"^(TASK|ACTION|MILESTONE|CHANGE_REQUEST|ISSUE)$")
    status: str = Field(default="TODO", pattern=r"^(TODO|IN_PROGRESS|BLOCKED|DONE|CANCELLED)$")
    priority: str = Field(default="MEDIUM", pattern=r"^(LOW|MEDIUM|HIGH|CRITICAL)$")
    project_id: uuid.UUID | None = None
    item_id: uuid.UUID | None = None
    org_unit_id: uuid.UUID | None = None
    document_id: uuid.UUID | None = None
    assignee_id: uuid.UUID | None = None
    start_date: date | None = None
    due_date: date | None = None
    progress: float = Field(default=0, ge=0, le=100)


def _wi(ctx: Ctx, w: WorkItem) -> dict:
    p = ctx.db.get(Project, w.project_id) if w.project_id else None
    it = ctx.db.get(EngineeringItem, w.item_id) if w.item_id else None
    d = ctx.db.get(Document, w.document_id) if w.document_id else None
    return {"id": str(w.id), "key": w.key, "title": w.title, "description": w.description, "kind": w.kind, "status": w.status, "priority": w.priority,
            "project": {"id": str(p.id), "code": p.code} if p else None, "item": {"id": str(it.id), "code": it.code, "name": it.name} if it else None,
            "document": {"id": str(d.id), "number": d.number} if d else None, "org_unit_id": str(w.org_unit_id) if w.org_unit_id else None,
            "assignee": user_brief(ctx.db.get(User, w.assignee_id)) if w.assignee_id else None, "reporter": user_brief(ctx.db.get(User, w.reporter_id)) if w.reporter_id else None,
            "start_date": iso(w.start_date), "due_date": iso(w.due_date), "progress": w.progress, "version": w.version, "updated_at": iso(w.updated_at)}


@router.get("/work-items")
def list_work_items(mine: bool = False, project_id: uuid.UUID | None = None, item_id: uuid.UUID | None = None, status: str | None = None, ctx: Ctx = Depends(get_ctx)):
    q = select(WorkItem)
    if mine:
        q = q.where(or_(WorkItem.assignee_id == ctx.user.id, WorkItem.reporter_id == ctx.user.id))
    elif not ctx.p.has_global("task.manage"):
        mine_projects = {g.scope_id for g in ctx.p.grants if g.scope_type == "PROJECT"}
        q = q.where(or_(WorkItem.assignee_id == ctx.user.id, WorkItem.reporter_id == ctx.user.id, WorkItem.project_id.in_(mine_projects or {uuid.uuid4()}), WorkItem.org_unit_id.in_(ctx.p.org_ids or {uuid.uuid4()})))
    if project_id:
        q = q.where(WorkItem.project_id == project_id)
    if item_id:
        q = q.where(WorkItem.item_id == item_id)
    if status:
        q = q.where(WorkItem.status.in_(status.split(",")))
    return [_wi(ctx, w) for w in ctx.db.execute(q.order_by(WorkItem.due_date.is_(None), WorkItem.due_date, WorkItem.created_at.desc()).limit(500)).scalars()]


@router.post("/work-items")
def create_work_item(body: WorkItemIn, ctx: Ctx = Depends(get_ctx)):
    if body.assignee_id and body.assignee_id != ctx.user.id and not ctx.p.has_any("task.manage"):
        raise Forbidden("You can create tasks for yourself; assigning others needs task management permission.")
    p = ctx.db.get(Project, body.project_id) if body.project_id else None
    prefix = p.code if p else "TSK"
    w = WorkItem(key=f"{prefix}-{next_seq(ctx.db, 'wi:' + prefix)}", reporter_id=ctx.user.id, **body.model_dump())
    ctx.db.add(w)
    ctx.db.flush()
    if w.assignee_id and w.assignee_id != ctx.user.id:
        notify(ctx.db, w.assignee_id, "task.assigned", f"New task {w.key}: {w.title}", f"Assigned by {ctx.user.full_name}", link=f"/tasks?open={w.id}")
    ctx.audit("task.create", "work_item", w.id, f"{w.key} created: {w.title}")
    ctx.db.commit()
    return _wi(ctx, w)


@router.put("/work-items/{wid}")
def update_work_item(wid: uuid.UUID, body: WorkItemIn, version: int | None = None, ctx: Ctx = Depends(get_ctx)):
    w = get_or_404(ctx.db, WorkItem, wid, "Task")
    if ctx.user.id not in (w.assignee_id, w.reporter_id) and not ctx.p.has_any("task.manage"):
        raise Forbidden("Only the assignee, reporter or a task manager can update this task.")
    if version is not None and version != w.version:
        from app.core.errors import Conflict

        raise Conflict("Task was updated by someone else. Refresh and try again.")
    old_status, old_assignee = w.status, w.assignee_id
    for k, v in body.model_dump().items():
        setattr(w, k, v)
    if w.status == "DONE" and old_status != "DONE":
        w.completed_at = utcnow()
        w.progress = 100
    w.version += 1
    if w.assignee_id and w.assignee_id != old_assignee and w.assignee_id != ctx.user.id:
        notify(ctx.db, w.assignee_id, "task.assigned", f"Task {w.key} assigned to you", w.title, link=f"/tasks?open={w.id}")
    ctx.audit("task.update", "work_item", w.id, f"{w.key} updated ({old_status} → {w.status})")
    ctx.db.commit()
    return _wi(ctx, w)
