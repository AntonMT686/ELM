import { Badge, Button, Card, Drawer, Group, Progress, SegmentedControl, Select, Slider, Stack, Text, Textarea, TextInput } from '@mantine/core'
import { DateInput } from '@mantine/dates'
import { IconCalendar, IconLayoutKanban, IconPlus } from '@tabler/icons-react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import dayjs from 'dayjs'
import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { api, errorText } from '../api/client'
import { useAction, useMe, useOrgUnits } from '../api/hooks'
import { PageTitle, UserAvatar } from '../components/common'
import { notifications } from '@mantine/notifications'
import { UserSelect } from './InboxPage'

const COLS = [
  { key: 'TODO', label: 'To do', color: 'gray' },
  { key: 'IN_PROGRESS', label: 'In progress', color: 'blue' },
  { key: 'BLOCKED', label: 'Blocked', color: 'red' },
  { key: 'DONE', label: 'Done', color: 'teal' },
]
const PRIO: Record<string, string> = { LOW: 'gray', MEDIUM: 'blue', HIGH: 'orange', CRITICAL: 'red' }
const KIND: Record<string, string> = { TASK: 'Task', ACTION: 'Action item', MILESTONE: 'Milestone', CHANGE_REQUEST: 'Change request', ISSUE: 'Issue' }

export default function TasksPage() {
  const [sp] = useSearchParams()
  const qc = useQueryClient()
  const [scope, setScope] = useState('mine')
  const { data = [] } = useQuery<any[]>({ queryKey: ['work-items', scope], queryFn: () => api.get('/work-items', { mine: scope === 'mine' }) })
  const [over, setOver] = useState<string | null>(null)
  const [edit, setEdit] = useState<any | null>(null)
  useEffect(() => { const o = sp.get('open'); if (o && data.length) setEdit(data.find((w) => w.id === o) || null) }, [sp, data])

  const move = async (w: any, status: string) => {
    if (w.status === status) return
    qc.setQueryData(['work-items', scope], (old: any[]) => old.map((x) => (x.id === w.id ? { ...x, status } : x)))
    try {
      await api.put(`/work-items/${w.id}`, { ...strip(w), status }, { version: w.version })
    } catch (e) { notifications.show({ color: 'red', message: errorText(e) }) }
    qc.invalidateQueries({ queryKey: ['work-items'] })
  }

  return (
    <div className="page" style={{ maxWidth: 1800 }}>
      <PageTitle icon={<IconLayoutKanban size={22} />} title="Tasks board" sub="Engineering and non-engineering work — action items, milestones, change requests, admin tasks. Drag cards to update status."
        extra={<><SegmentedControl value={scope} onChange={setScope} data={[{ label: 'Mine', value: 'mine' }, { label: 'My scope', value: 'scope' }]} /><Button leftSection={<IconPlus size={16} />} onClick={() => setEdit({})}>New task</Button></>} />
      <div className="kanban">
        {COLS.map((c) => {
          const items = data.filter((w) => w.status === c.key)
          return (
            <div key={c.key} className={`kanban-col ${over === c.key ? 'over' : ''}`} onDragOver={(e) => { e.preventDefault(); setOver(c.key) }} onDragLeave={() => setOver(null)}
              onDrop={(e) => { setOver(null); const w = data.find((x) => x.id === e.dataTransfer.getData('id')); if (w) move(w, c.key) }}>
              <Group justify="space-between" px={4} mb={8}><Group gap={6}><span style={{ width: 8, height: 8, borderRadius: 4, background: `var(--mantine-color-${c.color}-6)` }} /><Text fw={650} size="sm">{c.label}</Text></Group><Badge color={c.color} size="sm">{items.length}</Badge></Group>
              {items.map((w) => {
                const late = w.due_date && w.status !== 'DONE' && dayjs(w.due_date).isBefore(dayjs(), 'day')
                return (
                  <div key={w.id} className="kanban-card" draggable onDragStart={(e) => e.dataTransfer.setData('id', w.id)} onClick={() => setEdit(w)}>
                    <Group justify="space-between" gap={4}><Text size="xs" c="dimmed" fw={600}>{w.key}</Text><Badge size="xs" color={PRIO[w.priority]}>{w.priority}</Badge></Group>
                    <Text size="sm" fw={550} mt={4} lineClamp={2}>{w.title}</Text>
                    <Group gap={4} mt={6}>
                      {w.kind !== 'TASK' && <Badge size="xs" variant="outline" color="grape">{KIND[w.kind]}</Badge>}
                      {w.item && <Badge size="xs" color="violet">{w.item.code}</Badge>}
                      {w.document && <Badge size="xs" color="gray">{w.document.number}</Badge>}
                    </Group>
                    {w.status === 'IN_PROGRESS' && <Progress value={w.progress} size="xs" mt={8} />}
                    <Group justify="space-between" mt={8}>
                      <Text size="xs" c={late ? 'red' : 'dimmed'}>{w.due_date ? <><IconCalendar size={11} /> {dayjs(w.due_date).format('DD MMM')}</> : ''}</Text>
                      <UserAvatar user={w.assignee} size={22} />
                    </Group>
                  </div>
                )
              })}
            </div>
          )
        })}
      </div>
      <TaskDrawer task={edit} onClose={() => setEdit(null)} />
    </div>
  )
}

const strip = (w: any) => ({
  title: w.title, description: w.description, kind: w.kind, status: w.status, priority: w.priority, project_id: w.project?.id ?? w.project_id ?? null,
  item_id: w.item?.id ?? w.item_id ?? null, org_unit_id: w.org_unit_id ?? null, document_id: w.document?.id ?? w.document_id ?? null,
  assignee_id: w.assignee?.id ?? w.assignee_id ?? null, start_date: w.start_date ?? null, due_date: w.due_date ?? null, progress: w.progress ?? 0,
})

function TaskDrawer({ task, onClose }: { task: any | null; onClose: () => void }) {
  const { data: me } = useMe()
  const orgs = useOrgUnits()
  const [f, setF] = useState<any>({})
  useEffect(() => { if (task) setF(task.id ? strip(task) : { kind: 'TASK', status: 'TODO', priority: 'MEDIUM', assignee_id: me?.user.id, progress: 0 }) }, [task])
  const isNew = task && !task.id
  const save = useAction(() => (isNew ? api.post('/work-items', f) : api.put(`/work-items/${task.id}`, f, { version: task.version })), { success: isNew ? 'Task created' : 'Task updated', invalidate: [['work-items']], onDone: onClose })
  const set = (k: string) => (v: any) => setF((x: any) => ({ ...x, [k]: v }))
  return (
    <Drawer opened={!!task} onClose={onClose} position="right" size={460} title={<Text fw={650}>{isNew ? 'New task' : task?.key}</Text>}>
      <Stack>
        <TextInput label="Title" required value={f.title || ''} onChange={(e) => set('title')(e.currentTarget.value)} />
        <Group grow>
          <Select label="Kind" value={f.kind} onChange={set('kind')} data={Object.entries(KIND).map(([value, label]) => ({ value, label }))} />
          <Select label="Priority" value={f.priority} onChange={set('priority')} data={Object.keys(PRIO)} />
        </Group>
        <Group grow>
          <Select label="Status" value={f.status} onChange={set('status')} data={[...COLS.map((c) => ({ value: c.key, label: c.label })), { value: 'CANCELLED', label: 'Cancelled' }]} />
          <DateInput label="Due date" clearable value={f.due_date ? new Date(f.due_date) : null} onChange={(d) => set('due_date')(d ? dayjs(d).format('YYYY-MM-DD') : null)} />
        </Group>
        <UserSelect label="Assignee" value={f.assignee_id || null} onChange={set('assignee_id')} />
        <Select label="Project" clearable value={f.project_id || null} onChange={set('project_id')} data={(me?.projects || []).map((p) => ({ value: p.id, label: p.code }))} description="Leave empty for non-engineering / administrative work" />
        <Select label="Directorate / department" clearable searchable value={f.org_unit_id || null} onChange={set('org_unit_id')} data={(orgs.data || []).map((o) => ({ value: o.id, label: `${o.code} — ${o.name}` }))} />
        <div><Text size="sm" fw={500} mb={4}>Progress {f.progress}%</Text><Slider value={f.progress || 0} onChange={set('progress')} step={5} /></div>
        <Textarea label="Description" autosize minRows={3} value={f.description || ''} onChange={(e) => set('description')(e.currentTarget.value)} />
        {task?.reporter && <Group gap={6}><Text size="xs" c="dimmed">Reported by</Text><UserAvatar user={task.reporter} size={20} /><Text size="xs">{task.reporter.full_name}</Text></Group>}
        <Group justify="flex-end"><Button variant="default" onClick={onClose}>Cancel</Button><Button disabled={(f.title || '').length < 3} loading={save.isPending} onClick={() => save.mutate(undefined)}>Save</Button></Group>
        {!isNew && <Card withBorder p="xs"><Text size="xs" c="dimmed">Linked: {task?.item ? `${task.item.code} ${task.item.name}` : '—'} {task?.document ? `· ${task.document.number}` : ''}</Text></Card>}
      </Stack>
    </Drawer>
  )
}
